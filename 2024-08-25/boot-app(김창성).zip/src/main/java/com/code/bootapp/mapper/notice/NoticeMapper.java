package com.code.bootapp.mapper.notice;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface NoticeMapper {
}
