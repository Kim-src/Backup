package com.code.bootapp.utils;

public interface Constants {

	static final int BlOCK_PAGES = 10;
	static final int PAGE_ROWS = 10;
}
