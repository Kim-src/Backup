package com.code.bootapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
