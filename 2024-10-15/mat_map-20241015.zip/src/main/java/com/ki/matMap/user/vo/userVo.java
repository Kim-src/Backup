package com.ki.matMap.user.vo;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class userVo {
		private int memNo;
		private String memId;
	    private String memPwd;
	    private String memName;
	    private String memNick;
	    private String memPhone;
	    private String memEmail;
    
    
	 
    // Getters and Setters
}