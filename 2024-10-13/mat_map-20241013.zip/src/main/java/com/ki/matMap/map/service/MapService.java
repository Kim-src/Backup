package com.ki.matMap.map.service;

import java.util.List;

import com.ki.matMap.map.vo.MapVo;

public interface MapService {
	
	List<MapVo> getAllLocations(String rsYoutube);
}
