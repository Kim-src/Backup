package com.ki.matMap.restaurantDetail.vo;

import lombok.Data;

@Data
public class RsMenuVo {
	
	 private int rsMenuNo;
	 private int rsNo;
	 private String rsFoodMenu;
	 private int rsFoodPrice;
	
	
	

}
