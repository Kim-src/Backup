package com.ki.matMap.restaurantDetail.vo;

import lombok.Data;

@Data
public class RsImgVo {
	
	 private int rsImgNo;
	 private int rsNo;
	 private String rsImgPath;
	
	
}
