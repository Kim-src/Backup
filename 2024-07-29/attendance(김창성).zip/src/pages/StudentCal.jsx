import React from 'react';
import { Provider } from 'react-redux';
import { createStore } from 'redux';

const reducer = (state, action) => {
    console.log('dd', state, action);

    switch(action.type) {
        case 'deposit' :
            return state + Number(action.playload);
        case 'widthdraw' :
            return state - Number(action.playload);
        default :
            return state;
    }
}

function StudentCal(props) {

    const student = 0;

    function reducer(state = student, action) {
        if(action.type === '1') {
            state++;
            return state
        } else if(action.type === '0') {
            state--;
            return state
        } else {
            return state
        }
    }

    return (
        <div>
            
        </div>
    );
}

export default StudentCal;