import React, { useReducer, useState } from 'react';

const reducer = (state, action) => {

    switch(action.type) {
        case 'deposit' :
            return state + Number(action.playload);
        case 'widthdraw' :
            return state - Number(action.playload);
        default :
            return state;
    }
}

function StudentMain(props) {

    const [student, setStudent] = useState(0);
    const [money, dispatch] = useReducer(reducer, 0);

    const changeStudent = (type) => {
        const action = type === 'attendance' ? 'attendance' : 'absence';
        dispatch({type : action, playload : student})
    }

    return (
        <div>
            <div>출석 명부</div>
            <div>출석 : ```${student}```명</div>
            <div>결석 : 명</div>
            <div>출석률 : %</div>
            <table>
                <thead>
                    <tr>
                        <th>번호</th>
                        <th>이름</th>
                        <th>출석여부</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>블랙</td>
                        <td>
                        <input
                            type="radio"
                            id="attendance"
                            name="studentList"
                            value={student}
                            onChange={(e) => setStudent(e.target.value)}
                            onClick={() => {changeStudent('attendance')}}>
                        </input>
                        <label for="attendance">출석</label>
                        <input
                            type="radio"
                            id="absence"
                            name="studentList"
                            value={student}
                            onChange={(e) => setStudent(e.target.value)}
                            onClick={() => {changeStudent('absence')}}>
                        </input>
                        <label for="absence">결석</label>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
}

export default StudentMain;