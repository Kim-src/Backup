import React, { useState } from 'react';

const reducer = (state, action) => {

    switch(action.type) {
        case 'deposit' :
            return state + Number(action.playload);
        case 'widthdraw' :
            return state - Number(action.playload);
        default :
            return state;
    }
}

function useReducer(props) {

    const [number, setNumber] = useState(0);
    const [money, dispatch] = useReducer(reducer, 0);

    const changeMoney = (type) => {
        const action = type === 'd' ? 'deposit' : 'widthdraw';
        dispatch({type : action, playload : number})
    }

    return (
        <div>
            <div>
                <h2>useReducer 테스트</h2>
            </div>
            <div>
                <p>잔고 : {money}</p><br/>

                <input
                    type="number"
                    value={number}
                    onChange={(e) => setNumber(e.target.value)}>
                </input>
            </div>
            <div>
                <button onClick={() => {changeMoney('d')}}>입금</button>
                <button onClick={() => {changeMoney('w')}}>출금</button>
            </div>
        </div>
    );
}

export default useReducer;