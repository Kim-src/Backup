import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import BoardList from './pages/board/BoardList';
import MainPage from './pages/MainPage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainPage/>}></Route>
        <Route path="/board/list" element={<BoardList/>}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
