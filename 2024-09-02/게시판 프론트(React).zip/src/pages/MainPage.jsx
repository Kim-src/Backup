import React from 'react';
import MainLayout from './layout/MainLayout';

function MainPage(props) {
    // MainLayout의 children 설정
    return (
        <MainLayout>
            {/* MainLayout의 자식 prop */}
            <h1>메인 페이지</h1>
        </MainLayout>
    );
}

export default MainPage;