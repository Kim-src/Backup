import React, { Fragment } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import MenuHeader from './MenuHeader';

function MainLayout({children}) {
    return (
        <Fragment>
            <header>
                <MenuHeader/>
            </header>
            <main>
                {children}
            </main>
        </Fragment>
    );
}

export default MainLayout;