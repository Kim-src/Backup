import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState } from 'react';
import MainLayout from '../layout/MainLayout';
import  '../../assets/css/boardList.css'
import Pagination from 'react-js-pagination'

function BoardList(props) {

    const[nowPage, setNowPage] = useState(1);

    const pageHandler = (page) => {
        setNowPage(page);
    }

    // MainLayout의 children 설정
    return (
        <MainLayout>
            <section className='container'>
                <div className='content'>
                    <div className='txt-title'>
                        <h2>게시판 리스트</h2>
                    </div>
                    <div className='event-btn'>
                        <button className='btn btn-primary'>글쓰기</button>
                    </div>
                    <div>
                        <table className='table'>
                            <thead className='table-dark'>
                                <tr>
                                    <th scope='col'>번호</th>
                                    <th scope='col'>제목</th>
                                    <th scope='col'>작성자</th>
                                    <th scope='col'>조회수</th>
                                    <th scope='col'>최근 수정일</th>
                                </tr>
                            </thead>
                            <tbody id='listBody'>

                            </tbody>
                        </table>
                    </div>
                    <div className='page-area'>
                        <Pagination
                            activePage={nowPage}
                            itemsCountPerPage={10}
                            totalItemsCount={100}
                            pageRangeDisplayed={10}
                            prevPageText={'<'}
                            nextPageText={'>'}
                            onChange={pageHandler}
                        />
                    </div>
                </div>
            </section>
        </MainLayout>
    );
}

export default BoardList;