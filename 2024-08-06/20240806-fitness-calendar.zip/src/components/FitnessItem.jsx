import React from 'react';

function FitnessItem({ id, title, isChecked, onToggle, onDelete }) {
    return (
        <div className='fitness-item'>
            <input
                type="checkbox"
                checked={isChecked}
                onChange={() => onToggle(id, !isChecked)}
                style={{ marginRight: '5px' }}
            />
            <span
                style={{
                    textDecoration: isChecked ? 'line-through' : 'none',
                    color: isChecked ? 'gray' : 'white'
                }}
                onClick={() => onDelete(id)}
            >
                {title}
            </span>
        </div>
    );
}

export default FitnessItem;