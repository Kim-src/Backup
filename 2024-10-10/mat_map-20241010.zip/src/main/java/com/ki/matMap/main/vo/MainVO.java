package com.ki.matMap.main.vo;

public class MainVO {
    
    private int RS_NO;
    private String RS_NAME;
    private String RS_PLACE_ROAD;
    private String RS_PLACE_LOCAL;
    private double RS_LAT;
    private double RS_LONG;
    private String RS_PHONE;
    private String RS_OPEN_TIME;
    private String RS_CLOSE_TIME;
    private String RS_CLOSE_DAY;
    private char RS_FOOD_CATEGORY;
    private int RS_LIKES;
    private String RS_YOUTUBE;
    private String RS_YOUTUBE_IMG;
    
    public int getRS_NO() {
        return RS_NO;
    }

    public void setRS_NO(int RS_NO) {
        this.RS_NO = RS_NO;
    }

    public String getRS_NAME() {
        return RS_NAME;
    }

    public void setRS_NAME(String RS_NAME) {
        this.RS_NAME = RS_NAME;
    }

    public String getRS_PLACE_ROAD() {
        return RS_PLACE_ROAD;
    }

    public void setRS_PLACE_ROAD(String RS_PLACE_ROAD) {
        this.RS_PLACE_ROAD = RS_PLACE_ROAD;
    }

    public String getRS_PLACE_LOCAL() {
        return RS_PLACE_LOCAL;
    }

    public void setRS_PLACE_LOCAL(String RS_PLACE_LOCAL) {
        this.RS_PLACE_LOCAL = RS_PLACE_LOCAL;
    }

    public double getRS_LAT() {
        return RS_LAT;
    }

    public void setRS_LAT(double RS_LAT) {
        this.RS_LAT = RS_LAT;
    }

    public double getRS_LONG() {
        return RS_LONG;
    }

    public void setRS_LONG(double RS_LONG) {
        this.RS_LONG = RS_LONG;
    }

    public String getRS_PHONE() {
        return RS_PHONE;
    }

    public void setRS_PHONE(String RS_PHONE) {
        this.RS_PHONE = RS_PHONE;
    }

    public String getRS_OPEN_TIME() {
        return RS_OPEN_TIME;
    }

    public void setRS_OPEN_TIME(String RS_OPEN_TIME) {
        this.RS_OPEN_TIME = RS_OPEN_TIME;
    }

    public String getRS_CLOSE_TIME() {
        return RS_CLOSE_TIME;
    }

    public void setRS_CLOSE_TIME(String RS_CLOSE_TIME) {
        this.RS_CLOSE_TIME = RS_CLOSE_TIME;
    }

    public String getRS_CLOSE_DAY() {
        return RS_CLOSE_DAY;
    }

    public void setRS_CLOSE_DAY(String RS_CLOSE_DAY) {
        this.RS_CLOSE_DAY = RS_CLOSE_DAY;
    }

    public char getRS_FOOD_CATEGORY() {
        return RS_FOOD_CATEGORY;
    }

    public void setRS_FOOD_CATEGORY(char RS_FOOD_CATEGORY) {
        this.RS_FOOD_CATEGORY = RS_FOOD_CATEGORY;
    }

    public int getRS_LIKES() {
        return RS_LIKES;
    }

    public void setRS_LIKES(int RS_LIKES) {
        this.RS_LIKES = RS_LIKES;
    }

    public String getRS_YOUTUBE() {
        return RS_YOUTUBE;
    }

    public void setRS_YOUTUBE(String RS_YOUTUBE) {
        this.RS_YOUTUBE = RS_YOUTUBE;
    }

    public String getRS_YOUTUBE_IMG() {
        return RS_YOUTUBE_IMG;
    }

    public void setRS_YOUTUBE_IMG(String RS_YOUTUBE_IMG) {
        this.RS_YOUTUBE_IMG = RS_YOUTUBE_IMG;
    }

}
