package com.ki.matMap.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ki.matMap.main.mapper.MainMapper;
import com.ki.matMap.main.vo.MainVO;

@Service
public class MainServiceImplements implements MainService {
	
	@Autowired
	private MainMapper mainMapper;
	
	@Override
	public List<MainVO> searchMain(String keyword) {
		return mainMapper.searchMain(keyword);
	}

}
