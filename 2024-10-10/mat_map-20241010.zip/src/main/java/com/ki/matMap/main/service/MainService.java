package com.ki.matMap.main.service;

import java.util.List;

import com.ki.matMap.main.vo.MainVO;

public interface MainService {
	
	List<MainVO> searchMain(String keyword);

}
